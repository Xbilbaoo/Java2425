package jarduera2_4;

public abstract class Ariketa1 {

	public static void main(String[] args) {
		
		// Aldagaiak
		
		String esaldia1 = "Kaixo Zornotza";
		
		//Programa
		
		System.out.println(esaldia1.length() + " karaktere ditu Kaixo Zornotza esaldiak.");
		
	}

}
