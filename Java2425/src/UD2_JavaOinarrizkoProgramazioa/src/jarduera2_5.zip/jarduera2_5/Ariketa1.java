package jarduera2_5;

public class Ariketa1 {

	public static void main(String[] args) {
		
		String[] esaldiaArrai = new String[5];
		esaldiaArrai [0] = "Xabi";
		esaldiaArrai [1] = "Dani";
		esaldiaArrai [2] = "Ane";
		esaldiaArrai [3] = "Karmelo";
		esaldiaArrai [4] = "Aitor";
		
	}

}
