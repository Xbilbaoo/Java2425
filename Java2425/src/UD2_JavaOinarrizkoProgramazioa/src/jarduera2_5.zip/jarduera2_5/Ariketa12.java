package jarduera2_5;

public class Ariketa12 {

	public static void main(String[] args) {
		
		
	}

}
