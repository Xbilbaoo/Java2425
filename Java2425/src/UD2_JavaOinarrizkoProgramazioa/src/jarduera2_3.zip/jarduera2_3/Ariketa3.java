package jarduera2_3;

public class Ariketa3 {
	public static void main(String[] args) {

		// Aldagaiak

		int i = 0;

		// Programa

		for (i = 0; i <= 10; i++) {
			
			if (i != 5) {
				
				System.out.println( i );
				
			}			
		}
	}
}
