package jarduera2_3;

public class Ariketa4 {

	public static void main(String[] args) {

		// Aldagaiak

		int i = 0;

		// Programa

		for (i = 0; i >= 20; i --) {

			if (i % 2 == 0 && i >= 0) {

				System.out.println(i);
				
			}
		}

	}
}
