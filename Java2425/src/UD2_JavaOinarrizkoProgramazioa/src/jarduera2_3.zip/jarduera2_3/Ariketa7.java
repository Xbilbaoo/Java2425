package jarduera2_3;

public class Ariketa7 {

	public static void main(String[] args) {

		// Aldagaiak
		
		int i = 0;
		int emaitza = 0;
		
		// Programa
		
		for (i = 30; i <= 50; i ++) {
			
			emaitza = emaitza + i;
			
		}
		
		System.out.println( "30 eta 50 arteko zenbakien batura " + emaitza + " da.");
		
	}

}
